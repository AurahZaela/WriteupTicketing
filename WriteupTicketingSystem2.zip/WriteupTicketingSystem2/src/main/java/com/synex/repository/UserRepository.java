package com.synex.repository;

public interface UserRepository {

}
