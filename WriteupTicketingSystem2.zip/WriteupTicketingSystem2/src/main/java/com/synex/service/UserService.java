package com.synex.service;

public class UserService {

}
