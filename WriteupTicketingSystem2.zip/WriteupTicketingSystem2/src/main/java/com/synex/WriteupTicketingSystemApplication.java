package com.synex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WriteupTicketingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(WriteupTicketingSystemApplication.class, args);
	}

}
