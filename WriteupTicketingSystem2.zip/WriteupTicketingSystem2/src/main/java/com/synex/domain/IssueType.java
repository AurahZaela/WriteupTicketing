package com.synex.domain;

public enum IssueType {
	BUG,TASK,IMPROVEMENT
}
