package com.synex.domain;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Entity
@Setter
@Getter
@AllArgsConstructor	
@NoArgsConstructor
public class Workflow {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long workflowId;

    private String name;

    private String description;

    @OneToMany(mappedBy = "workflow", cascade = CascadeType.ALL)
    private Set<WorkflowStatus> statuses;

}
