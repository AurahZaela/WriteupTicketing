package com.synex.domain;

import jakarta.persistence.*;
import java.util.Set;
import lombok.*;

@Entity
@Setter
@Getter
@AllArgsConstructor	
@NoArgsConstructor
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long userId;
	
	private String username;
	private String email;
	private String password;
	
	@Enumerated(EnumType.STRING)
	private Role role;
}
