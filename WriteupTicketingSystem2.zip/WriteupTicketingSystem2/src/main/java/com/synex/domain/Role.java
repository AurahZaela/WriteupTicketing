package com.synex.domain;

public enum Role {
	ADMIN,PROJECT_MANAGER,DEVELOPER,VIEWER
}
