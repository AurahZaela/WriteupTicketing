package com.synex.domain;

public enum Priority {
	 LOW, MEDIUM, HIGH
}
