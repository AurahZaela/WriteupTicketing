package com.synex.domain;

public enum Status {
	OPEN,IN_PROGRESS,RESOLVED,CLOSED
}
