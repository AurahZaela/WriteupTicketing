package com.synex.domain;
import jakarta.persistence.*;

import java.util.Date;
import lombok.*;

@Entity
@Setter
@Getter
@AllArgsConstructor	
@NoArgsConstructor
public class Issue {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long issueId;
	
	@ManyToOne
	@JoinColumn(name="projectId")
	private Project project;
	
	@ManyToOne
	@JoinColumn(name="reporterId")
	private User reporter;
	
	@ManyToOne
	@JoinColumn(name="assigneeId")
	private User assignee;
	
	private String summary;
	private String description;
	
	@Enumerated(EnumType.STRING)
	private IssueType issueType;
	
	@Enumerated(EnumType.STRING)
	private Status status;
	
	@Enumerated(EnumType.STRING)
	private Priority priority;
	
	private Date creationDate;
	private Date updateDate;
}
