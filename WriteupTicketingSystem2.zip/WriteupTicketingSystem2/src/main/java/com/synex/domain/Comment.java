package com.synex.domain;

import jakarta.persistence.*;

import java.util.Date;
import lombok.*;

@Entity
@Setter
@Getter
@AllArgsConstructor	
@NoArgsConstructor
public class Comment {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long commentId;
	
	@ManyToOne
    @JoinColumn(name = "issueId")
    private Issue issue;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

    private String text;

    private Date timestamp;
}
