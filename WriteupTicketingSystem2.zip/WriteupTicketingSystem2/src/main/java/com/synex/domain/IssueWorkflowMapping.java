package com.synex.domain;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Setter
@Getter
@AllArgsConstructor	
@NoArgsConstructor
public class IssueWorkflowMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long mappingId;

    @ManyToOne
    @JoinColumn(name = "issueId", nullable = false)
    private Issue issue;

    @ManyToOne
    @JoinColumn(name = "statusId", nullable = false)
    private WorkflowStatus status;

}
